import { Row } from './Table';

export type BlockAttributes = {
	resourceTypes: Row[];
}

